package com.redis;

import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import redis.clients.jedis.Jedis;

@RestController
public class Controller {

	@RequestMapping("redisdata")
	public String sayHello() throws Exception {
		String data = new String(Files.readAllBytes(
				Paths.get("C:\\Users\\suhasp\\Desktop\\JSONFile.txt")));
		Jedis jedis = new Jedis("192.168.195.181", 6379);
		try {

			JSONObject obj = new JSONObject(data);
			JSONArray n = obj.getJSONArray("servers");
			System.out.println(n);
			for (int i = 0; i < n.length(); i++) {

				String key = n.getJSONObject(i).getString("server");
				JSONObject value = n.getJSONObject(i);
				System.out.println("key:" + key);
				System.out.println("value:" + value);
				System.out.println("Connection to server sucessfully established");
				jedis.set(key, value.toString());
				
}
			System.out.println("Inserted Successfully");
		} finally {
		jedis.close();
		}
		return "INSERTED SUCCESSFULLY.";
	}
}
